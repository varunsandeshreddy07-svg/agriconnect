import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { PriceTicker } from './components/PriceTicker';
import { Marketplace } from './components/Marketplace';
import { TradingPlanGenerator } from './components/TradingPlanGenerator';
import { FarmerDashboard } from './components/FarmerDashboard';
import { ListingDetailModal } from './components/ListingDetailModal';
import { CreateListingModal } from './components/CreateListingModal';
import { AiAssistantModal } from './components/AiAssistantModal';
import { FarmerVerificationModal } from './components/FarmerVerificationModal';
import { ChatDrawer } from './components/ChatDrawer';
import { CollegeDemoGuide } from './components/CollegeDemoGuide';
import { MOCK_LISTINGS, MOCK_FARMERS, MOCK_BUYERS, MOCK_CONVERSATIONS } from './data/mockData';
import { CropListing, Conversation, UserRole, TradeOffer, ChatMessage } from './types';
import { Sparkles, Bot } from 'lucide-react';

const INITIAL_FARMER_USER = {
  id: 'farmer-1',
  name: 'Ramesh Patel',
  role: 'farmer' as const,
  avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80',
  organizationOrFarm: 'Patel Bio-Organic Agro Farm (18 Acres)',
  location: 'Bardoli, Surat, Gujarat',
  phone: '+91 98254 11209',
  verificationLevel: 'gold_certified' as const,
};

const INITIAL_BUYER_USER = {
  id: 'buyer-user',
  name: 'Rajesh Singhania',
  role: 'buyer' as const,
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
  organizationOrFarm: 'Apex Food Processing & Exports Corp',
  location: 'New Delhi / Mundra Port Hub',
  phone: '+91 98110 44219',
  verificationLevel: 'gold_certified' as const,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'marketplace' | 'plan-generator' | 'my-farm' | 'ai-assistant'>('marketplace');
  const [userRole, setUserRole] = useState<UserRole>({
    type: 'farmer',
    currentUser: INITIAL_FARMER_USER,
  });

  const [listings, setListings] = useState<CropListing[]>(MOCK_LISTINGS);
  const [conversations, setConversations] = useState<Conversation[]>(MOCK_CONVERSATIONS);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(MOCK_CONVERSATIONS[0]?.id || null);

  // Modals state
  const [selectedListing, setSelectedListing] = useState<CropListing | null>(null);
  const [isCreateListingOpen, setIsCreateListingOpen] = useState(false);
  const [isAiAdvisorOpen, setIsAiAdvisorOpen] = useState(false);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showCollegeGuide, setShowCollegeGuide] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Toggle user role between Farmer & Buyer
  const handleToggleRole = () => {
    if (userRole.type === 'farmer') {
      setUserRole({
        type: 'buyer',
        currentUser: INITIAL_BUYER_USER,
      });
      showToast('Switched persona to: Rajesh Singhania (AgriProcessor Buyer)');
    } else {
      setUserRole({
        type: 'farmer',
        currentUser: INITIAL_FARMER_USER,
      });
      showToast('Switched persona to: Ramesh Patel (Verified Farmer)');
    }
  };

  // Add new listing
  const handleAddListing = (newListing: CropListing) => {
    setListings(prev => [newListing, ...prev]);
    showToast(`✓ Published "${newListing.title}" to marketplace!`);
    setActiveTab('marketplace');
  };

  // Open direct chat for a listing
  const handleOpenMessageForListing = (listing: CropListing, initialOffer?: { quantity: number; price: number }) => {
    setSelectedListing(null);

    // Find or create conversation
    let targetConv = conversations.find(c => c.otherParty.id === listing.farmer.id || c.cropContext?.id === listing.id);

    if (!targetConv) {
      targetConv = {
        id: `conv-${Date.now()}`,
        otherParty: {
          id: listing.farmer.id,
          name: listing.farmer.name,
          role: 'farmer',
          avatar: listing.farmer.avatar,
          verificationLevel: listing.farmer.verificationLevel,
          phone: listing.farmer.phone,
          location: `${listing.farmer.village}, ${listing.farmer.district}`,
        },
        lastMessage: 'Started inquiry for this lot.',
        lastMessageTime: 'Just now',
        unreadCount: 0,
        cropContext: {
          id: listing.id,
          title: listing.title,
          price: listing.pricePerUnit,
          quantity: listing.quantity,
          unit: listing.unit,
          image: listing.images[0],
        },
        messages: [],
      };
      setConversations(prev => [targetConv!, ...prev]);
    }

    setActiveConversationId(targetConv.id);

    if (initialOffer) {
      const offer: TradeOffer = {
        id: `offer-${Date.now()}`,
        cropId: listing.id,
        cropTitle: listing.title,
        proposedPrice: initialOffer.price,
        proposedQuantity: initialOffer.quantity,
        unit: listing.unit,
        totalAmount: initialOffer.price * initialOffer.quantity,
        status: 'pending',
        createdAt: 'Just now',
      };

      handleSendMessage(
        targetConv.id,
        `Hello ${listing.farmer.name}, I am submitting a trade bid of ${initialOffer.quantity} ${listing.unit} at ₹${initialOffer.price}/${listing.unit === 'quintals' ? 'qtl' : listing.unit}.`,
        offer
      );
    }

    setIsChatOpen(true);
  };

  // Send message in chat
  const handleSendMessage = (conversationId: string, text: string, offerDetails?: TradeOffer) => {
    const conv = conversations.find(c => c.id === conversationId);
    const recipientId = conv ? conv.otherParty.id : 'user';

    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: userRole.currentUser.id,
      senderName: userRole.currentUser.name,
      senderRole: userRole.type === 'buyer' ? 'buyer' : 'farmer',
      recipientId,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      offerDetails,
      read: false,
    };

    setConversations(prev =>
      prev.map(c => {
        if (c.id === conversationId) {
          return {
            ...c,
            lastMessage: text,
            lastMessageTime: 'Just now',
            messages: [...c.messages, newMessage],
          };
        }
        return c;
      })
    );
  };

  // Update offer status
  const handleUpdateOfferStatus = (conversationId: string, messageId: string, newStatus: 'accepted' | 'declined') => {
    setConversations(prev =>
      prev.map(conv => {
        if (conv.id === conversationId) {
          return {
            ...conv,
            messages: conv.messages.map(m => {
              if (m.id === messageId && m.offerDetails) {
                return {
                  ...m,
                  offerDetails: {
                    ...m.offerDetails,
                    status: newStatus,
                  },
                };
              }
              return m;
            }),
          };
        }
        return conv;
      })
    );

    if (newStatus === 'accepted') {
      showToast('🎉 Trade Offer Accepted! Digital Escrow contract initialized.');
    } else {
      showToast('Trade Offer declined.');
    }
  };

  // Upgrade verification
  const handleUpgradeVerification = () => {
    setUserRole(prev => ({
      ...prev,
      currentUser: {
        ...prev.currentUser,
        verificationLevel: 'gold_certified',
      },
    }));
    showToast('🏆 Land Record Verified! Upgraded to Gold Certified Farmer.');
  };

  // 1-Click Demo Actions from the Viva Guide
  const handleTriggerDemoAction = (action: string) => {
    switch (action) {
      case 'test-ai-pest':
        setIsAiAdvisorOpen(true);
        break;
      case 'test-plan':
        setActiveTab('plan-generator');
        break;
      case 'test-chat-negotiate':
        setIsChatOpen(true);
        break;
      case 'test-verification':
        setIsVerificationOpen(true);
        break;
      case 'switch-role':
        handleToggleRole();
        break;
      default:
        break;
    }
  };

  const totalUnreadMessages = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans selection:bg-emerald-200">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white px-3.5 py-2 rounded-xl shadow-lg border border-slate-700 flex items-center gap-2 text-xs font-bold animate-in slide-in-from-top duration-200">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: 'marketplace' | 'plan-generator' | 'my-farm' | 'ai-assistant') => {
          if (tab === 'ai-assistant') {
            setIsAiAdvisorOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        userRole={userRole}
        onToggleRole={handleToggleRole}
        onOpenNewListing={() => setIsCreateListingOpen(true)}
        onOpenVerification={() => setIsVerificationOpen(true)}
        onOpenMessages={() => setIsChatOpen(true)}
        unreadMessagesCount={totalUnreadMessages}
      />

      {/* Live Market Price Index Ticker */}
      <PriceTicker />

      {/* Main App Canvas */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 space-y-4">
        {/* Viva / Evaluator Presentation Guide */}
        {showCollegeGuide && (
          <CollegeDemoGuide
            onTriggerDemoAction={handleTriggerDemoAction}
            onClose={() => setShowCollegeGuide(false)}
          />
        )}

        {/* View 1: Marketplace Browsing & Search */}
        {activeTab === 'marketplace' && (
          <Marketplace
            listings={listings}
            onSelectListing={(listing) => setSelectedListing(listing)}
            onOpenNewListing={() => setIsCreateListingOpen(true)}
            onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
            userRole={userRole}
          />
        )}

        {/* View 2: Precision Farming & Trading Plan Generator */}
        {activeTab === 'plan-generator' && <TradingPlanGenerator />}

        {/* View 3: Farmer Operations & Lot Management */}
        {activeTab === 'my-farm' && (
          <FarmerDashboard
            listings={listings}
            userRole={userRole}
            onOpenNewListing={() => setIsCreateListingOpen(true)}
            onOpenVerification={() => setIsVerificationOpen(true)}
            onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
            onSelectListing={(listing) => setSelectedListing(listing)}
            onOpenMessages={() => setIsChatOpen(true)}
          />
        )}
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-2">
        <button
          onClick={() => setIsAiAdvisorOpen(true)}
          className="w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg flex items-center justify-center transition transform hover:scale-105 cursor-pointer border border-emerald-500"
          title="Open AI Farming Assistant & Voice Advisor"
          id="floating-ai-assistant-btn"
        >
          <Bot className="w-6 h-6" />
        </button>
      </div>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-4 border-t border-slate-800 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-emerald-600 flex items-center justify-center text-white font-bold text-[10px]">
              🌾
            </div>
            <span className="font-bold text-white text-xs">AgriConnect</span>
            <span className="text-[11px] text-slate-400">• Direct Farmer-to-Buyer Agritech Platform</span>
          </div>

          <div className="flex items-center gap-3 text-slate-400 text-[11px]">
            <span>Empowering Indian Growers & Agri Processors</span>
            <span>•</span>
            <button
              onClick={() => setShowCollegeGuide(true)}
              className="text-amber-400 hover:underline font-semibold cursor-pointer"
            >
              Evaluation Guide
            </button>
          </div>
        </div>
      </footer>

      {/* Modals and Drawers */}
      <ListingDetailModal
        listing={selectedListing}
        onClose={() => setSelectedListing(null)}
        onOpenMessage={handleOpenMessageForListing}
      />

      <CreateListingModal
        isOpen={isCreateListingOpen}
        onClose={() => setIsCreateListingOpen(false)}
        onAddListing={handleAddListing}
        userRole={userRole}
      />

      <AiAssistantModal
        isOpen={isAiAdvisorOpen}
        onClose={() => setIsAiAdvisorOpen(false)}
      />

      <FarmerVerificationModal
        isOpen={isVerificationOpen}
        onClose={() => setIsVerificationOpen(false)}
        userRole={userRole}
        onUpgradeVerification={handleUpgradeVerification}
      />

      <ChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        conversations={conversations}
        activeConversationId={activeConversationId}
        setActiveConversationId={(id) => setActiveConversationId(id)}
        onSendMessage={handleSendMessage}
        onUpdateOfferStatus={handleUpdateOfferStatus}
        userRole={userRole}
      />
    </div>
  );
}
